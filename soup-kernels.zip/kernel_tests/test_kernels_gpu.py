"""Run on a CUDA machine (Kaggle T4):  python -m pytest -q kernel_tests/test_kernels_gpu.py
(kept outside tests/ on purpose: tests/ and harness/ are reserved by the challenge)."""
import pytest
import torch

cuda = pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")


def ref_rms(x, w, eps):
    dt = x.dtype
    xf = x.float()
    xf = xf * torch.rsqrt(xf.pow(2).mean(-1, keepdim=True) + eps)
    return w * xf.to(dt)


@cuda
@pytest.mark.parametrize("xdt,wdt", [(torch.float32, torch.float32), (torch.float16, torch.float32), (torch.float16, torch.float16)])
@pytest.mark.parametrize("shape", [(2048, 1536), (7, 1536), (3, 5, 1536), (11, 2000)])
def test_rmsnorm(xdt, wdt, shape):
    from solution.kernels.rmsnorm import rmsnorm
    torch.manual_seed(0)
    x = (torch.randn(shape, device="cuda") * 3).to(xdt).requires_grad_()
    w = torch.randn(shape[-1], device="cuda").to(wdt)
    dy = torch.randn(shape, device="cuda").to(torch.promote_types(xdt, wdt))
    x2 = x.detach().clone().requires_grad_()
    y = rmsnorm(x, w, 1e-6); y.backward(dy)
    yr = ref_rms(x2, w, 1e-6); yr.backward(dy)
    assert y.dtype == yr.dtype and x.grad.dtype == x2.grad.dtype
    tol = 2e-3 if xdt == torch.float16 else 1e-5
    assert torch.allclose(y.float(), yr.float(), rtol=tol, atol=tol)
    assert torch.allclose(x.grad.float(), x2.grad.float(), rtol=5 * tol, atol=5 * tol)


@cuda
@pytest.mark.parametrize("dt", [torch.float16, torch.float32])
def test_swiglu(dt):
    from solution.kernels.swiglu import swiglu
    torch.manual_seed(0)
    g = (torch.randn(2048, 8960, device="cuda") * 2).to(dt).requires_grad_()
    u = torch.randn(2048, 8960, device="cuda").to(dt).requires_grad_()
    do = torch.randn(2048, 8960, device="cuda").to(dt)
    g2, u2 = g.detach().clone().requires_grad_(), u.detach().clone().requires_grad_()
    swiglu(g, u).backward(do)
    (torch.nn.functional.silu(g2) * u2).backward(do)
    tol = 2e-3 if dt == torch.float16 else 1e-5
    assert torch.allclose(g.grad.float(), g2.grad.float(), rtol=tol, atol=tol)
    assert torch.allclose(u.grad.float(), u2.grad.float(), rtol=tol, atol=tol)


@cuda
@pytest.mark.parametrize("N,V,chunk", [(300, 5000, 64), (257, 151936, 128), (1000, 151936, None)])
def test_fused_linear_ce(N, V, chunk):
    from solution.kernels.ce import fused_linear_ce
    torch.manual_seed(0)
    H = 1536
    h = (torch.randn(N, H, device="cuda") * 0.5).half().requires_grad_()
    W = (torch.randn(V, H, device="cuda") * 0.05).half()
    labels = torch.randint(0, V, (N,), device="cuda")
    labels[torch.rand(N, device="cuda") < 0.25] = -100
    nll, ent, cor = fused_linear_ce(h, W, labels, chunk)
    g = torch.randn(N, device="cuda")
    nll.backward(g)

    h2 = h.detach().clone().requires_grad_()
    logits = (h2 @ W.t()).float()
    lp = torch.log_softmax(logits, -1)
    valid = labels >= 0
    nll_r = torch.where(valid, -lp.gather(1, labels.clamp(min=0)[:, None])[:, 0], torch.zeros((), device="cuda"))
    ent_r = -(lp.exp() * lp).sum(-1)
    cor_r = (valid & (logits.argmax(-1) == labels)).float()
    nll_r.backward(g)
    assert torch.allclose(nll, nll_r, rtol=1e-3, atol=1e-3)
    assert torch.allclose(ent, ent_r, rtol=1e-3, atol=1e-3)
    assert (cor != cor_r).float().mean() < 1e-3          # fp16 near-ties may differ on a handful of rows
    rel = (h.grad.float() - h2.grad.float()).norm() / h2.grad.float().norm()
    assert rel < 2e-2, rel
