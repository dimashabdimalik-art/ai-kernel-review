"""Micro-benchmark vs eager PyTorch (time with CUDA events, peak memory).  python kernel_tests/bench_kernels.py"""
import torch
import torch.nn.functional as F
from solution.kernels.rmsnorm import rmsnorm
from solution.kernels.swiglu import swiglu
from solution.kernels.ce import fused_linear_ce


def timeit(fn, iters=20, warm=3):
    for _ in range(warm):
        fn()
    torch.cuda.synchronize()
    a, b = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    a.record()
    for _ in range(iters):
        fn()
    b.record(); torch.cuda.synchronize()
    return a.elapsed_time(b) / iters


def peak(fn):
    torch.cuda.synchronize(); torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats()
    base = torch.cuda.memory_allocated()
    fn(); torch.cuda.synchronize()
    return (torch.cuda.max_memory_allocated() - base) / 2**20


dev = "cuda"
M, H, I, V = 2048, 1536, 8960, 151936

# RMSNorm (fp32 residual stream, fp32 weight: what kbit-prepared Qwen produces)
x = torch.randn(M, H, device=dev, requires_grad=True); w = torch.randn(H, device=dev)
def eager_rms():
    xf = x.float(); y = w * (xf * torch.rsqrt(xf.pow(2).mean(-1, keepdim=True) + 1e-6)).to(x.dtype); y.sum().backward()
def trit_rms():
    rmsnorm(x, w, 1e-6).sum().backward()
print(f"RMSNorm fwd+bwd  eager {timeit(eager_rms):.3f} ms | triton {timeit(trit_rms):.3f} ms")

g = torch.randn(M, I, device=dev, dtype=torch.half, requires_grad=True); u = torch.randn(M, I, device=dev, dtype=torch.half, requires_grad=True)
def eager_sw(): (F.silu(g) * u).sum().backward()
def trit_sw(): swiglu(g, u).sum().backward()
print(f"SwiGLU fwd+bwd   eager {timeit(eager_sw):.3f} ms | triton {timeit(trit_sw):.3f} ms | peak MiB eager {peak(eager_sw):.0f} triton {peak(trit_sw):.0f}")

h = torch.randn(M, H, device=dev, dtype=torch.half, requires_grad=True); W = (torch.randn(V, H, device=dev, dtype=torch.half) * 0.05)
lab = torch.randint(0, V, (M,), device=dev)
def eager_ce():
    lg = (h @ W.t()).float(); lp = torch.log_softmax(lg, -1)
    nll = -lp.gather(1, lab[:, None]).sum()
    with torch.no_grad():
        (-(lp.exp() * lp).sum(-1)).mean(); (lg.argmax(-1) == lab).float().mean()
    nll.backward()
def trit_ce():
    nll, ent, cor = fused_linear_ce(h, W, lab); nll.sum().backward()
print(f"Linear+CE        eager {timeit(eager_ce, 5, 1):.1f} ms | triton {timeit(trit_ce, 5, 1):.1f} ms | peak MiB eager {peak(eager_ce):.0f} triton {peak(trit_ce):.0f}")
