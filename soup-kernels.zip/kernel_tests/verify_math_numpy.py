"""CPU/numpy check of the *algorithms* used by the Triton kernels (not of the Triton code itself).
Mirrors the kernels step by step (per-lane online softmax, masked tail, ties, ignore rows, chunked
backward) in float64 and compares with a straightforward reference and finite differences."""
import numpy as np

rng = np.random.default_rng(0)
np.seterr(all="ignore")


# ---------- CE stats: mirror of _ce_stats_kernel ----------
def ce_stats_row(x_row, label, BLOCK_V):
    V = x_row.size
    lane = np.arange(BLOCK_V)
    m_vec = np.full(BLOCK_V, -np.inf); a_vec = np.zeros(BLOCK_V); b_vec = np.zeros(BLOCK_V)
    best_val = np.full(BLOCK_V, -np.inf); best_idx = np.zeros(BLOCK_V, dtype=np.int64)
    for start in range(0, V, BLOCK_V):
        offs = start + lane
        mask = offs < V
        x = np.where(mask, x_row[np.minimum(offs, V - 1)], -np.inf)
        new_m = np.maximum(m_vec, x)
        scale = np.where(m_vec == new_m, 1.0, np.exp(m_vec - new_m))
        e = np.where(mask, np.exp(x - new_m), 0.0)
        xs = np.where(mask, x, 0.0)
        a_vec = a_vec * scale + e
        b_vec = b_vec * scale + e * xs
        m_vec = new_m
        upd = x > best_val
        best_idx = np.where(upd, offs, best_idx)
        best_val = np.where(upd, x, best_val)
    big_m = m_vec.max()
    sc = np.exp(m_vec - big_m)
    a = (a_vec * sc).sum(); b = (b_vec * sc).sum()
    lse = big_m + np.log(a)
    ent = lse - b / a
    top = best_val.max()
    arg = np.where(best_val == top, best_idx, 2**31 - 1).min()
    valid = label >= 0
    x_lab = x_row[label if valid else 0]
    nll = lse - x_lab if valid else 0.0
    correct = 1.0 if (valid and arg == label) else 0.0
    return lse, nll, ent, correct


def ce_bwd_row(x_row, label, lse, g, BLOCK_V):
    V = x_row.size
    out = np.zeros(V)
    g = g if label >= 0 else 0.0
    for c in range((V + BLOCK_V - 1) // BLOCK_V):
        offs = c * BLOCK_V + np.arange(BLOCK_V)
        mask = offs < V
        x = np.where(mask, x_row[np.minimum(offs, V - 1)], 0.0)
        p = np.exp(x - lse)
        d = np.where(offs == label, p - 1.0, p) * g
        out[offs[mask]] = d[mask]
    return out


def linear_ce_emulated(h, W, labels, g_nll, chunk, BLOCK_V):
    N = h.shape[0]; V = W.shape[0]
    lse = np.empty(N); nll = np.empty(N); ent = np.empty(N); cor = np.empty(N)
    for s in range(0, N, chunk):
        e = min(N, s + chunk)
        logits = h[s:e] @ W.T
        for r in range(e - s):
            lse[s + r], nll[s + r], ent[s + r], cor[s + r] = ce_stats_row(logits[r], labels[s + r], BLOCK_V)
    dh = np.empty_like(h)
    for s in range(0, N, chunk):
        e = min(N, s + chunk)
        logits = h[s:e] @ W.T
        for r in range(e - s):
            logits[r] = ce_bwd_row(logits[r], labels[s + r], lse[s + r], g_nll[s + r], BLOCK_V)
        dh[s:e] = logits @ W
    return nll, ent, cor, dh


def reference(h, W, labels, g_nll):
    logits = h @ W.T
    m = logits.max(1, keepdims=True)
    lse = (m + np.log(np.exp(logits - m).sum(1, keepdims=True)))[:, 0]
    p = np.exp(logits - lse[:, None])
    valid = labels >= 0
    nll = np.where(valid, lse - logits[np.arange(len(labels)), np.where(valid, labels, 0)], 0.0)
    ent = lse - (p * logits).sum(1)
    cor = (valid & (logits.argmax(1) == labels)).astype(float)
    onehot = np.zeros_like(p); onehot[np.arange(len(labels)), np.where(valid, labels, 0)] = 1
    dl = (p - onehot) * (g_nll * valid)[:, None]
    return nll, ent, cor, dl @ W


def check_ce():
    worst = 0.0
    for (N, H, V, chunk, BV) in [(13, 6, 37, 4, 8), (9, 5, 64, 9, 16), (31, 8, 1000, 7, 128), (5, 4, 7, 2, 16)]:
        h = rng.normal(size=(N, H)); W = rng.normal(size=(V, H)) * 2
        labels = rng.integers(0, V, size=N); labels[rng.random(N) < 0.3] = -100
        g = rng.normal(size=N)
        got = linear_ce_emulated(h, W, labels, g, chunk, BV)
        ref = reference(h, W, labels, g)
        for a, b, nm in zip(got, ref, ["nll", "ent", "correct", "dh"]):
            err = np.abs(a - b).max()
            worst = max(worst, err)
            assert err < 1e-9, (nm, err, (N, H, V, chunk, BV))
    # ties: first index must win, also across lane/block boundaries
    x = np.zeros(40); x[[3, 20, 35]] = 5.0
    assert ce_stats_row(x, 20, 8)[3] == 0.0 and ce_stats_row(x, 3, 8)[3] == 1.0
    # large logits: no overflow in online softmax
    x = rng.normal(size=300) * 50 + 800
    assert np.isfinite(ce_stats_row(x, 5, 64)[0])
    # finite differences of loss = sum(g*nll) wrt h
    N, H, V = 6, 5, 40
    h = rng.normal(size=(N, H)); W = rng.normal(size=(V, H)); labels = rng.integers(0, V, size=N); labels[1] = -100
    g = rng.normal(size=N)
    dh = linear_ce_emulated(h, W, labels, g, 4, 8)[3]
    fd = np.zeros_like(h); eps = 1e-6
    for i in range(N):
        for j in range(H):
            hp = h.copy(); hp[i, j] += eps; hm = h.copy(); hm[i, j] -= eps
            fd[i, j] = ((g * reference(hp, W, labels, g)[0]).sum() - (g * reference(hm, W, labels, g)[0]).sum()) / (2 * eps)
    assert np.abs(fd - dh).max() < 1e-6, np.abs(fd - dh).max()
    print(f"CE ok (max err vs ref {worst:.2e}; FD ok)")


# ---------- RMSNorm ----------
def rms_fwd(x, w, eps):
    rstd = 1 / np.sqrt((x * x).mean(-1, keepdims=True) + eps)
    return x * rstd * w, rstd


def rms_bwd(dy, x, w, rstd):
    wdy = w * dy
    c = (wdy * x).mean(-1, keepdims=True)
    return (wdy - x * rstd ** 2 * c) * rstd


def check_rms():
    x = rng.normal(size=(5, 12)); w = rng.normal(size=12); dy = rng.normal(size=(5, 12)); eps = 1e-6
    y, rstd = rms_fwd(x, w, eps)
    dx = rms_bwd(dy, x, w, rstd)
    fd = np.zeros_like(x); h = 1e-6
    for i in range(5):
        for j in range(12):
            xp = x.copy(); xp[i, j] += h; xm = x.copy(); xm[i, j] -= h
            fd[i, j] = ((rms_fwd(xp, w, eps)[0] - rms_fwd(xm, w, eps)[0]) * dy).sum() / (2 * h)
    assert np.abs(fd - dx).max() < 1e-7
    print("RMSNorm ok (FD)")


# ---------- SwiGLU ----------
def sig(z): return 1 / (1 + np.exp(-z))


def check_swiglu():
    g = rng.normal(size=(4, 9)) * 3; u = rng.normal(size=(4, 9)); do = rng.normal(size=(4, 9))
    s = sig(g)
    du = do * g * s
    dg = do * u * s * (1 + g * (1 - s))
    f = lambda gg, uu: gg * sig(gg) * uu
    h = 1e-6
    fdg = (f(g + h, u) - f(g - h, u)) / (2 * h) * do
    fdu = (f(g, u + h) - f(g, u - h)) / (2 * h) * do
    assert np.abs(fdg - dg).max() < 1e-6 and np.abs(fdu - du).max() < 1e-6
    print("SwiGLU ok (FD)")


if __name__ == "__main__":
    check_ce(); check_rms(); check_swiglu()
    print("ALL MATH CHECKS PASSED")
