"""Chunked fused linear + cross-entropy (+ entropy + top-1 accuracy) for a huge vocabulary.

The eager path materialises logits [B*S, V] (V=151936) in fp16, then .float(), log_softmax,
softmax-for-entropy, argmax-for-accuracy, and their gradients: several GB at batch 4 x 512.
Here logits only ever exist for `chunk` rows at a time, and ONE Triton pass over each logits row
produces: logsumexp, NLL, entropy and argmax-correctness.  Backward recomputes the chunk's logits,
turns them in place into dlogits = g * (softmax - onehot) with a second Triton kernel, and does
dh = dlogits @ W.  The lm_head weight is frozen -> no dW.

GEMMs stay in torch (tensor cores); the Triton kernels do the V-wide softmax work.
Rows with label < 0 (ignore_index) get nll = 0 and zero gradient; entropy/correct are still
reported for them (caller masks), because trainers differ in which mask they average over.
"""
import torch
import triton
import triton.language as tl

_BLOCK_V = 2048


@triton.jit
def _ce_stats_kernel(LOGITS, LABELS, LSE, NLL, ENT, CORRECT, V, stride_l, BLOCK_V: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    base = LOGITS + row * stride_l
    label = tl.load(LABELS + row)

    lane = tl.arange(0, BLOCK_V)
    m_vec = tl.full([BLOCK_V], float("-inf"), tl.float32)
    a_vec = tl.zeros([BLOCK_V], tl.float32)
    b_vec = tl.zeros([BLOCK_V], tl.float32)
    best_val = tl.full([BLOCK_V], float("-inf"), tl.float32)
    best_idx = tl.zeros([BLOCK_V], tl.int32)

    for start in range(0, V, BLOCK_V):
        offs = start + lane
        mask = offs < V
        x = tl.load(base + offs, mask=mask, other=float("-inf")).to(tl.float32)
        new_m = tl.maximum(m_vec, x)
        scale = tl.where(m_vec == new_m, 1.0, tl.exp(m_vec - new_m))
        e = tl.where(mask, tl.exp(x - new_m), 0.0)
        xs = tl.where(mask, x, 0.0)
        a_vec = a_vec * scale + e
        b_vec = b_vec * scale + e * xs
        m_vec = new_m
        upd = x > best_val
        best_idx = tl.where(upd, offs, best_idx)
        best_val = tl.where(upd, x, best_val)

    big_m = tl.max(m_vec, axis=0)
    sc = tl.exp(m_vec - big_m)
    a = tl.sum(a_vec * sc, axis=0)
    b = tl.sum(b_vec * sc, axis=0)
    lse = big_m + tl.log(a)
    ent = lse - b / a

    top = tl.max(best_val, axis=0)
    arg = tl.min(tl.where(best_val == top, best_idx, 2147483647), axis=0)

    valid = label >= 0
    safe_label = tl.where(valid, label, 0)
    x_lab = tl.load(base + safe_label).to(tl.float32)
    nll = tl.where(valid, lse - x_lab, 0.0)
    correct = tl.where(valid & (arg == label), 1.0, 0.0)

    tl.store(LSE + row, lse)
    tl.store(NLL + row, nll)
    tl.store(ENT + row, ent)
    tl.store(CORRECT + row, correct)


@triton.jit
def _ce_bwd_kernel(LOGITS, LABELS, LSE, GRAD, V, stride_l, BLOCK_V: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    offs = tl.program_id(1) * BLOCK_V + tl.arange(0, BLOCK_V)
    mask = offs < V
    base = LOGITS + row * stride_l
    label = tl.load(LABELS + row)
    lse = tl.load(LSE + row)
    g = tl.load(GRAD + row)
    g = tl.where(label >= 0, g, 0.0)
    x = tl.load(base + offs, mask=mask, other=0.0).to(tl.float32)
    p = tl.exp(x - lse)
    d = tl.where(offs == label, p - 1.0, p) * g
    tl.store(base + offs, d.to(LOGITS.dtype.element_ty), mask=mask)


def _chunk_rows(V, budget_bytes=192 * 1024 * 1024, elem=2):
    return max(64, (budget_bytes // (V * elem)) // 64 * 64)


class FusedLinearCEFn(torch.autograd.Function):
    @staticmethod
    def forward(ctx, h, W, labels, chunk):
        N, _ = h.shape
        V = W.shape[0]
        dev = h.device
        lse = torch.empty(N, dtype=torch.float32, device=dev)
        nll = torch.empty_like(lse)
        ent = torch.empty_like(lse)
        cor = torch.empty_like(lse)
        for s in range(0, N, chunk):
            e = min(N, s + chunk)
            logits = h[s:e] @ W.t()                     # [c, V] fp16, tensor cores
            _ce_stats_kernel[(e - s,)](logits, labels[s:e], lse[s:e], nll[s:e], ent[s:e], cor[s:e],
                                       V, logits.stride(0), BLOCK_V=_BLOCK_V, num_warps=8)
            del logits
        ctx.save_for_backward(h, W, labels, lse)
        ctx.chunk = chunk
        ctx.mark_non_differentiable(ent, cor)
        return nll, ent, cor

    @staticmethod
    def backward(ctx, g_nll, g_ent, g_cor):
        h, W, labels, lse = ctx.saved_tensors
        N, _ = h.shape
        V = W.shape[0]
        g_nll = g_nll.contiguous().float()
        dh = torch.empty_like(h)
        grid_v = triton.cdiv(V, _BLOCK_V)
        for s in range(0, N, ctx.chunk):
            e = min(N, s + ctx.chunk)
            logits = h[s:e] @ W.t()
            _ce_bwd_kernel[(e - s, grid_v)](logits, labels[s:e], lse[s:e], g_nll[s:e], V,
                                            logits.stride(0), BLOCK_V=_BLOCK_V, num_warps=8)
            dh[s:e] = logits @ W
            del logits
        return dh, None, None, None


def fused_linear_ce(h, W, labels, chunk=None):
    """h:[N,H] fp16 contiguous, W:[V,H] fp16 contiguous (frozen), labels:[N] int64 (-100 = ignore).
    Returns (nll[N] fp32 differentiable wrt h, entropy[N] fp32, correct[N] fp32 0/1)."""
    assert h.dtype == torch.float16 and W.dtype == torch.float16 and h.is_contiguous() and W.is_contiguous()
    assert not W.requires_grad, "lm_head is expected to be frozen"
    chunk = chunk or _chunk_rows(W.shape[0])
    return FusedLinearCEFn.apply(h, W, labels.contiguous(), chunk)
