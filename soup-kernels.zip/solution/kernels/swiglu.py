"""Fused SwiGLU:  out = silu(gate) * up.

Forward is one pass; backward recomputes sigmoid from the saved gate/up (which are the linear
outputs and are saved anyway), so the eager intermediates silu(gate) and silu(gate)*up are never
kept alive for backward -> less activation memory and fewer elementwise kernels.

    s = sigmoid(g);  out = g*s*u
    du = dout * g*s
    dg = dout * u * s * (1 + g*(1-s))
"""
import torch
import triton
import triton.language as tl

_BLOCK = 1024


@triton.jit
def _swiglu_fwd_kernel(G, U, O, n, BLOCK: tl.constexpr):
    offs = tl.program_id(0).to(tl.int64) * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n
    g = tl.load(G + offs, mask=mask, other=0.0).to(tl.float32)
    u = tl.load(U + offs, mask=mask, other=0.0).to(tl.float32)
    o = g * tl.sigmoid(g) * u
    tl.store(O + offs, o.to(O.dtype.element_ty), mask=mask)


@triton.jit
def _swiglu_bwd_kernel(DO, G, U, DG, DU, n, BLOCK: tl.constexpr):
    offs = tl.program_id(0).to(tl.int64) * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n
    do = tl.load(DO + offs, mask=mask, other=0.0).to(tl.float32)
    g = tl.load(G + offs, mask=mask, other=0.0).to(tl.float32)
    u = tl.load(U + offs, mask=mask, other=0.0).to(tl.float32)
    s = tl.sigmoid(g)
    du = do * g * s
    dg = do * u * s * (1.0 + g * (1.0 - s))
    tl.store(DG + offs, dg.to(DG.dtype.element_ty), mask=mask)
    tl.store(DU + offs, du.to(DU.dtype.element_ty), mask=mask)


class SwiGLUFn(torch.autograd.Function):
    @staticmethod
    def forward(ctx, g, u):
        g = g.contiguous()
        u = u.contiguous()
        out = torch.empty_like(g)
        n = g.numel()
        _swiglu_fwd_kernel[(triton.cdiv(n, _BLOCK),)](g, u, out, n, BLOCK=_BLOCK, num_warps=4)
        ctx.save_for_backward(g, u)
        return out

    @staticmethod
    def backward(ctx, do):
        g, u = ctx.saved_tensors
        do = do.contiguous()
        dg = torch.empty_like(g)
        du = torch.empty_like(u)
        n = g.numel()
        _swiglu_bwd_kernel[(triton.cdiv(n, _BLOCK),)](do, g, u, dg, du, n, BLOCK=_BLOCK, num_warps=4)
        return dg, du


def swiglu(gate, up):
    return SwiGLUFn.apply(gate, up)
