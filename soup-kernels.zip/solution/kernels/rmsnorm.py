"""Fused RMSNorm for a *frozen* weight: forward + backward-to-input in one Triton kernel each.

Replaces the HF eager sequence (cast to fp32, pow, mean, rsqrt, mul, cast back, mul weight)
that costs ~7 elementwise kernels forward and more backward, for every one of the 57 norms.
Own implementation; the math is the textbook RMSNorm derivative.

    y = w * x * rstd,   rstd = 1 / sqrt(mean(x^2) + eps)
    dx = rstd * (w*dy - x * rstd^2 * mean(w*dy*x))
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _rmsnorm_fwd_kernel(X, W, Y, RSTD, stride_x, stride_y, N, eps, BLOCK_N: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    cols = tl.arange(0, BLOCK_N)
    mask = cols < N
    x = tl.load(X + row * stride_x + cols, mask=mask, other=0.0).to(tl.float32)
    rstd = 1.0 / tl.sqrt(tl.sum(x * x, axis=0) / N + eps)
    w = tl.load(W + cols, mask=mask, other=0.0).to(tl.float32)
    y = x * rstd * w
    tl.store(Y + row * stride_y + cols, y.to(Y.dtype.element_ty), mask=mask)
    tl.store(RSTD + row, rstd)


@triton.jit
def _rmsnorm_bwd_kernel(DY, X, W, RSTD, DX, stride_dy, stride_x, stride_dx, N, BLOCK_N: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    cols = tl.arange(0, BLOCK_N)
    mask = cols < N
    dy = tl.load(DY + row * stride_dy + cols, mask=mask, other=0.0).to(tl.float32)
    x = tl.load(X + row * stride_x + cols, mask=mask, other=0.0).to(tl.float32)
    w = tl.load(W + cols, mask=mask, other=0.0).to(tl.float32)
    rstd = tl.load(RSTD + row)
    wdy = w * dy
    c = tl.sum(wdy * x, axis=0) / N
    dx = (wdy - x * (rstd * rstd) * c) * rstd
    tl.store(DX + row * stride_dx + cols, dx.to(DX.dtype.element_ty), mask=mask)


def _cfg(N):
    block = triton.next_power_of_2(N)
    if block > 16384:
        raise ValueError(f"RMSNorm width {N} too large for single-block kernel")
    warps = 4 if block <= 2048 else 8
    return block, warps


class RMSNormFn(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, weight, eps):
        shape = x.shape
        N = shape[-1]
        x2 = x.reshape(-1, N)
        if x2.stride(-1) != 1:
            x2 = x2.contiguous()
        M = x2.shape[0]
        y = torch.empty((M, N), dtype=torch.promote_types(x.dtype, weight.dtype), device=x.device)
        rstd = torch.empty(M, dtype=torch.float32, device=x.device)
        block, warps = _cfg(N)
        _rmsnorm_fwd_kernel[(M,)](x2, weight, y, rstd, x2.stride(0), y.stride(0), N, eps,
                                  BLOCK_N=block, num_warps=warps)
        ctx.save_for_backward(x2, weight, rstd)
        ctx.shape = shape
        return y.view(shape)

    @staticmethod
    def backward(ctx, dy):
        x2, weight, rstd = ctx.saved_tensors
        M, N = x2.shape
        dy2 = dy.reshape(-1, N)
        if dy2.stride(-1) != 1:
            dy2 = dy2.contiguous()
        dx = torch.empty_like(x2)
        block, warps = _cfg(N)
        _rmsnorm_bwd_kernel[(M,)](dy2, x2, weight, rstd, dx, dy2.stride(0), x2.stride(0), dx.stride(0), N,
                                  BLOCK_N=block, num_warps=warps)
        return dx.view(ctx.shape), None, None


def rmsnorm(x, weight, eps):
    """weight must NOT require grad (frozen base norm); caller falls back otherwise."""
    return RMSNormFn.apply(x, weight, eps)
