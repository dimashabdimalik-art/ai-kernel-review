"""Soup Kernel Challenge solution package (work in progress).

apply() wires our Triton kernels into Soup/HF. Fused cross-entropy (kernels/ce.py) is NOT wired
yet: it needs the exact loss/metrics code path of Soup 0.77.0 + TRL from the starter repo.
"""


def apply(rmsnorm=True, swiglu=True):
    from .patches import patch_qwen2
    patch_qwen2(rmsnorm_on=rmsnorm, swiglu_on=swiglu)
