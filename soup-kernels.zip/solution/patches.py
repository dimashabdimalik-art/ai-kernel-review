"""Monkey-patches for HF Qwen2 that route RMSNorm and SwiGLU through our Triton kernels.
Always falls back to the original eager path when a precondition does not hold."""
import torch

from .kernels.rmsnorm import rmsnorm
from .kernels.swiglu import swiglu

_FLAG = "_soup_kernels_patched"


def patch_qwen2(rmsnorm_on=True, swiglu_on=True):
    from transformers.models.qwen2 import modeling_qwen2 as M

    if rmsnorm_on and not getattr(M.Qwen2RMSNorm, _FLAG, False):
        orig = M.Qwen2RMSNorm.forward

        def fwd(self, hidden_states):
            if hidden_states.is_cuda and not self.weight.requires_grad:
                return rmsnorm(hidden_states, self.weight, self.variance_epsilon)
            return orig(self, hidden_states)

        M.Qwen2RMSNorm.forward = fwd
        setattr(M.Qwen2RMSNorm, _FLAG, True)

    if swiglu_on and not getattr(M.Qwen2MLP, _FLAG, False):
        orig_mlp = M.Qwen2MLP.forward

        def mlp_fwd(self, x):
            if x.is_cuda and getattr(self.config, "hidden_act", "silu") == "silu":
                return self.down_proj(swiglu(self.gate_proj(x), self.up_proj(x)))
            return orig_mlp(self, x)

        M.Qwen2MLP.forward = mlp_fwd
        setattr(M.Qwen2MLP, _FLAG, True)
