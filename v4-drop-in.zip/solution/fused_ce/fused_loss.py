"""Glue between HF Qwen2 / TRL 0.29.1 SFTTrainer / Soup's rewind recorder and the fused CE kernels.

Stock path (what we replace): lm_head -> logits [B,T,152k] fp16 -> .float() -> CE; then TRL again walks the
full logits for entropy and argmax-accuracy, and Soup's rewind recorder walks them once more.

Fused path: the model runs with an identity lm_head (so `outputs.logits` is just the hidden states), HF's own
`loss_function` hook is swapped for ours, which feeds only non-pad rows through `fused_linear_ce`.  One
Triton pass per row yields NLL, entropy and top-1 hit, from which we rebuild exactly what TRL logs:

  * loss              = sum(nll) / num_items_in_batch      (mean over valid tokens if it is None) -- same as HF
  * entropy           = sum_t entropy_t * attention_mask_t / attention_mask.sum()    (TRL: unshifted, all non-pad)
  * mean_token_accuracy = hits / supervised tokens, position t predicts labels[t+1]  (TRL: shifted)
  * rewind per-token loss (B,T): position t holds CE of labels[t+1], 0 elsewhere  (Soup's logits-free protocol)

Everything falls back to the untouched TRL path on any unsupported setting or on any exception.
"""
import contextlib
import types
import warnings

import torch
import torch.nn as nn
import torch.nn.functional as F

from .ce_kernels import fused_linear_ce_sum

_DISABLED = False


class _Passthrough(nn.Module):
    def forward(self, x):
        return x


class FusedStats:
    def __init__(self):
        self.idx = self.nll = self.ent = self.cor = self.lab = None


def find_causal_lm(model):
    """The real *ForCausalLM module (PeftModel forwards unknown attributes, so look in own _modules only)."""
    for m in model.modules():
        head = m._modules.get("lm_head") if hasattr(m, "_modules") else None
        if isinstance(head, nn.Linear) and "model" in m._modules:
            return m
    return None


@contextlib.contextmanager
def fused_head(base, attention_mask):
    lm_head = base._modules["lm_head"]
    weight = lm_head.weight
    stats = FusedStats()

    def loss_fn(logits, labels, vocab_size, num_items_in_batch=None, ignore_index=-100, shift_labels=None, **kwargs):
        if shift_labels is not None or ignore_index != -100:
            raise RuntimeError("fused loss: shift_labels / custom ignore_index not supported")
        hidden = logits                                   # identity head -> these are hidden states [B,T,H]
        B, T, H = hidden.shape
        tgt = F.pad(labels, (0, 1), value=-100)[:, 1:]    # label of the token that position t predicts
        idx = attention_mask.reshape(-1).nonzero(as_tuple=True)[0]
        h = hidden.reshape(B * T, H).to(torch.float16).index_select(0, idx).contiguous()
        lab = tgt.reshape(-1).index_select(0, idx).contiguous()
        total, nll, ent, cor = fused_linear_ce_sum(h, weight, lab)
        if num_items_in_batch is not None:
            if torch.is_tensor(num_items_in_batch):
                num_items_in_batch = num_items_in_batch.to(total.device)
            loss = total / num_items_in_batch
        else:
            loss = total / (lab != -100).sum().clamp(min=1)
        stats.idx, stats.nll, stats.ent, stats.cor, stats.lab = idx, nll, ent, cor, lab
        return loss

    had_lf = "_loss_function" in base.__dict__
    prev_lf = base.__dict__.get("_loss_function")
    base.lm_head = _Passthrough()
    base.loss_function = loss_fn
    try:
        yield stats
    finally:
        base.lm_head = lm_head
        if had_lf:
            base.__dict__["_loss_function"] = prev_lf
        else:
            base.__dict__.pop("_loss_function", None)


def _eligible(trainer, model, inputs):
    if _DISABLED:
        return None
    a = trainer.args
    if not trainer.model.training or getattr(a, "use_liger_kernel", False):
        return None
    if "labels" not in inputs or "attention_mask" not in inputs or "shift_labels" in inputs:
        return None
    if getattr(trainer, "num_virtual_tokens", 0) > 0 or getattr(trainer, "aux_loss_enabled", False):
        return None
    if getattr(a, "loss_type", "nll") != "nll" or getattr(a, "n_gpu", 1) > 1:
        return None
    if getattr(trainer, "compute_loss_func", None) is not None or getattr(trainer, "label_smoother", None) is not None:
        return None
    base = find_causal_lm(model)
    if base is None:
        return None
    head = base._modules["lm_head"]
    if head.bias is not None or head.weight.requires_grad or not head.weight.is_cuda:
        return None
    return base


def patch_trl_sft():
    """Replace SFTTrainer.compute_loss (TRL 0.29.x only: it mirrors that version's metric code)."""
    import trl
    from trl.trainer import sft_trainer as S

    if not str(trl.__version__).startswith("0.29"):
        warnings.warn(f"soup-kernels: fused CE skipped, written for TRL 0.29.x, found {trl.__version__}")
        return False
    if getattr(S.SFTTrainer, "_soup_kernels_fused_ce", False):
        return True
    try:
        from soup_cli.utils.stream_loss_chunk import STEP_ATTR as step_attr
    except Exception:
        step_attr = None

    orig = S.SFTTrainer.compute_loss

    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        global _DISABLED
        base = _eligible(self, model, inputs)
        if base is None:
            return orig(self, model, inputs, return_outputs=return_outputs, num_items_in_batch=num_items_in_batch)
        try:
            inputs["use_cache"] = False
            with fused_head(base, inputs["attention_mask"]) as st:
                loss, outputs = super(S.SFTTrainer, self).compute_loss(
                    model, inputs, return_outputs=True, num_items_in_batch=num_items_in_batch
                )
            if st.idx is None:
                raise RuntimeError("model did not call loss_function (transformers internals differ)")
            att = inputs["attention_mask"]
            with torch.no_grad():
                entropy = self.accelerator.gather_for_metrics(st.ent.sum() / att.sum()).mean().item()
                num_tokens = self.accelerator.gather_for_metrics(att.sum()).sum().item()
                correct = self.accelerator.gather_for_metrics(st.cor.sum().long())
                total = self.accelerator.gather_for_metrics((st.lab != -100).sum())
                total_sum = total.sum()
                accuracy = (correct.sum() / total_sum).item() if total_sum > 0 else 0.0
                if step_attr is not None:
                    B, T = att.shape
                    token_loss = torch.zeros(B * T, dtype=torch.float32, device=att.device)
                    token_loss[st.idx] = st.nll
                    setattr(self, step_attr, types.SimpleNamespace(token_loss=token_loss.view(B, T)))
        except Exception as exc:
            _DISABLED = True
            warnings.warn(f"soup-kernels: fused CE disabled, using stock path ({type(exc).__name__}: {exc})")
            return orig(self, model, inputs, return_outputs=return_outputs, num_items_in_batch=num_items_in_batch)

        mode = "train"
        self._metrics[mode]["entropy"].append(entropy)
        self._total_train_tokens += num_tokens
        self._metrics[mode]["num_tokens"] = [self._total_train_tokens]
        self._metrics[mode]["mean_token_accuracy"].append(accuracy)
        outputs.logits = None            # it only held hidden states; Soup's rewind then uses token_loss above
        return (loss, outputs) if return_outputs else loss

    S.SFTTrainer.compute_loss = compute_loss
    S.SFTTrainer._soup_kernels_fused_ce = True
    return True
