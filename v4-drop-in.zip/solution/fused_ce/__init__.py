"""Fused LM-head + cross-entropy for Soup 0.77.0 / TRL 0.29.1 / transformers 5.16.1.

Usage (one line inside the existing solution.apply()):

    from .fused_ce import install
    install()
"""


def install():
    from .fused_loss import patch_trl_sft
    return patch_trl_sft()
