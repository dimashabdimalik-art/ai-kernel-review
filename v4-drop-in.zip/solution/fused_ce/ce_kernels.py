"""Chunked fused linear + cross-entropy (+ entropy + top-1 hit) over a huge vocabulary, ONE pass, no recompute.

Stock path: logits [B*T, 151936] fp16 -> .float() -> log_softmax (kept for backward) -> NLL, then TRL walks the full
logits again for entropy and argmax, then backward builds another fp32 [B*T, V] gradient: several GB and many
full-size memory passes.

Here, per chunk of `chunk` non-pad rows (logits for ~190 MiB at a time):
  1. logits_c = h_c @ W^T                       (torch GEMM, tensor cores)
  2. _ce_stats_kernel: one Triton pass over each row -> lse, NLL, entropy, top-1 hit
  3. _ce_bwd_kernel : same logits buffer overwritten in place with  S * (softmax - onehot)   (S = 64, keeps tiny
                      probabilities representable in fp16; undone later)
  4. dh0_c = dlogits_c @ W                      (torch GEMM)  -- only rows that have a label
The upstream gradient of  total = sum(NLL)  is a scalar g, so backward is just  dh = dh0 * g / S : no recompute,
no second pass over the vocabulary.  The lm_head weight is frozen (no dW).
"""
import torch
import triton
import triton.language as tl

_BLOCK_V = 2048
_GRAD_SCALE = 64.0


@triton.jit
def _ce_stats_kernel(LOGITS, LABELS, LSE, NLL, ENT, CORRECT, V, stride_l, BLOCK_V: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    base = LOGITS + row * stride_l
    label = tl.load(LABELS + row)

    lane = tl.arange(0, BLOCK_V)
    m_vec = tl.full([BLOCK_V], float("-inf"), tl.float32)
    a_vec = tl.zeros([BLOCK_V], tl.float32)
    b_vec = tl.zeros([BLOCK_V], tl.float32)
    best_val = tl.full([BLOCK_V], float("-inf"), tl.float32)
    best_idx = tl.zeros([BLOCK_V], tl.int32)

    for start in range(0, V, BLOCK_V):
        offs = start + lane
        mask = offs < V
        x = tl.load(base + offs, mask=mask, other=float("-inf")).to(tl.float32)
        new_m = tl.maximum(m_vec, x)
        scale = tl.where(m_vec == new_m, 1.0, tl.exp(m_vec - new_m))
        e = tl.where(mask, tl.exp(x - new_m), 0.0)
        xs = tl.where(mask, x, 0.0)
        a_vec = a_vec * scale + e
        b_vec = b_vec * scale + e * xs
        m_vec = new_m
        upd = x > best_val
        best_idx = tl.where(upd, offs, best_idx)
        best_val = tl.where(upd, x, best_val)

    big_m = tl.max(m_vec, axis=0)
    sc = tl.exp(m_vec - big_m)
    a = tl.sum(a_vec * sc, axis=0)
    b = tl.sum(b_vec * sc, axis=0)
    lse = big_m + tl.log(a)
    ent = lse - b / a

    top = tl.max(best_val, axis=0)
    arg = tl.min(tl.where(best_val == top, best_idx, 2147483647), axis=0)

    valid = label >= 0
    safe_label = tl.where(valid, label, 0)
    x_lab = tl.load(base + safe_label).to(tl.float32)
    nll = tl.where(valid, lse - x_lab, 0.0)
    correct = tl.where(valid & (arg == label), 1.0, 0.0)

    tl.store(LSE + row, lse)
    tl.store(NLL + row, nll)
    tl.store(ENT + row, ent)
    tl.store(CORRECT + row, correct)


@triton.jit
def _ce_bwd_kernel(LOGITS, LABELS, LSE, scale, V, stride_l, BLOCK_V: tl.constexpr):
    row = tl.program_id(0).to(tl.int64)
    offs = tl.program_id(1) * BLOCK_V + tl.arange(0, BLOCK_V)
    mask = offs < V
    base = LOGITS + row * stride_l
    label = tl.load(LABELS + row)
    lse = tl.load(LSE + row)
    x = tl.load(base + offs, mask=mask, other=0.0).to(tl.float32)
    p = tl.exp(x - lse)
    d = tl.where(offs == label, p - 1.0, p) * scale
    d = tl.where(label >= 0, d, 0.0)
    tl.store(base + offs, d.to(LOGITS.dtype.element_ty), mask=mask)


def _chunk_rows(V, budget_bytes=192 * 1024 * 1024, elem=2):
    return max(64, (budget_bytes // (V * elem)) // 64 * 64)


class FusedLinearCESumFn(torch.autograd.Function):
    @staticmethod
    def forward(ctx, h, W, labels, chunk):
        N, _ = h.shape
        V = W.shape[0]
        dev = h.device
        Wh = W if W.dtype == torch.float16 else W.to(torch.float16)   # transient copy, freed on return
        lse = torch.empty(N, dtype=torch.float32, device=dev)
        nll = torch.empty_like(lse)
        ent = torch.empty_like(lse)
        cor = torch.empty_like(lse)
        dh0 = torch.zeros_like(h) if ctx.needs_input_grad[0] else None
        grid_v = triton.cdiv(V, _BLOCK_V)
        for s in range(0, N, chunk):
            e = min(N, s + chunk)
            lab_c = labels[s:e]
            logits = h[s:e] @ Wh.t()                                   # [c, V] fp16
            _ce_stats_kernel[(e - s,)](logits, lab_c, lse[s:e], nll[s:e], ent[s:e], cor[s:e],
                                       V, logits.stride(0), BLOCK_V=_BLOCK_V, num_warps=8)
            if dh0 is not None:
                sel = (lab_c >= 0).nonzero(as_tuple=True)[0]
                k = sel.numel()
                if k == e - s:                                         # every row has a label: in place
                    _ce_bwd_kernel[(k, grid_v)](logits, lab_c, lse[s:e], _GRAD_SCALE, V,
                                                logits.stride(0), BLOCK_V=_BLOCK_V, num_warps=8)
                    dh0[s:e] = logits @ Wh
                elif k > 0:                                            # only some rows: copy those, skip the rest
                    lg = logits.index_select(0, sel)
                    _ce_bwd_kernel[(k, grid_v)](lg, lab_c.index_select(0, sel), lse[s:e].index_select(0, sel),
                                                _GRAD_SCALE, V, lg.stride(0), BLOCK_V=_BLOCK_V, num_warps=8)
                    dh0[s:e].index_copy_(0, sel, lg @ Wh)
                    del lg
            del logits
        total = nll.sum()
        if dh0 is not None:
            ctx.save_for_backward(dh0)
        ctx.mark_non_differentiable(nll, ent, cor)
        return total, nll, ent, cor

    @staticmethod
    def backward(ctx, g_total, g_nll, g_ent, g_cor):
        if not ctx.needs_input_grad[0]:
            return None, None, None, None
        (dh0,) = ctx.saved_tensors
        dh = (dh0.float() * (g_total.float() / _GRAD_SCALE)).to(dh0.dtype)
        return dh, None, None, None


def fused_linear_ce_sum(h, W, labels, chunk=None):
    """h:[N,H] fp16 contiguous (may require grad); W:[V,H] frozen lm_head weight (fp16 or fp32);
    labels:[N] int64, -100 = ignore.  Returns (total, nll[N], entropy[N], correct[N]):
    total = sum(nll) is differentiable wrt h; the per-row outputs are fp32 and non-differentiable."""
    assert h.dtype == torch.float16 and h.is_contiguous() and W.is_contiguous()
    assert not W.requires_grad, "lm_head is expected to be frozen"
    chunk = chunk or _chunk_rows(W.shape[0])
    return FusedLinearCESumFn.apply(h, W, labels.contiguous(), chunk)
