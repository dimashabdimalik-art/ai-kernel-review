"""Soup Kernel Challenge solution package.

Call apply() before Soup constructs its Qwen2 model / TRL trainer.
"""
from __future__ import annotations

from .entropy import patch_trl_entropy
from .int8_swiglu import patch_qwen2_mlp_int8
from .rmsnorm import patch_qwen2_rmsnorm
from .rope import patch_qwen2_rope

_APPLIED = None


def apply():
    """Install the custom Triton paths. Safe to call more than once."""
    global _APPLIED
    if _APPLIED is not None:
        return dict(_APPLIED)

    # Patch module-level Qwen2 functions/classes before model construction.
    results = {
        "qwen2_mlp_block_int8": patch_qwen2_mlp_int8(),
        "qwen2_rmsnorm": patch_qwen2_rmsnorm(),
        "qwen2_rope": patch_qwen2_rope(),
        "trl_entropy": patch_trl_entropy(),
    }
    # V4: fused LM-head + cross-entropy (replaces the logits chain in TRL's compute_loss).
    # Wrapped so that any problem here can never break the already validated V1 patches.
    try:
        from .fused_ce import install

        results["fused_ce"] = bool(install())
    except Exception as exc:  # pragma: no cover
        import warnings

        warnings.warn(f"fused_ce not installed: {type(exc).__name__}: {exc}")
        results["fused_ce"] = False

    _APPLIED = results
    return dict(results)


__all__ = ["apply"]
